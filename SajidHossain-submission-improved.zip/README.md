
# Project: Algorithm Implementations

## Description
This project implements two fundamental algorithms:
1. **Selection Sort**: A simple comparison-based sorting algorithm.
2. **Recursive Binary Search**: A search algorithm that uses recursion to find an element in a sorted list.

## Folder Structure
- `src/`: Contains the main code implementations.
- `tests/`: Contains test scripts to verify the correctness of the algorithms.
- `README.md`: This file, explaining the project and how to run it.

## How to Run

### Prerequisites
Ensure you have Python 3.x installed.

### Running the Code
Navigate to the `src/` folder and execute the scripts:

```bash
cd src
python selection_sort.py
python recursive_binary_search.py
```

### Running Tests
To verify the correctness of the algorithms, navigate to the `tests/` folder and execute the test scripts:

```bash
cd tests
python test_selection_sort.py
python test_recursive_binary_search.py
```

### Expected Results
- **Selection Sort**: The output will display a sorted version of the input list.
- **Recursive Binary Search**: The output will display whether an element exists in the list and its position.

## Edge Cases Covered
- Empty lists
- Single-element lists
- Lists with duplicate elements
- Lists with negative and positive numbers

## Author
Sajid Hossain
